Adds some stuff. Too lazy to write a README.
