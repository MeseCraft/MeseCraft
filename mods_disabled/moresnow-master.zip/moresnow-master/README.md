
Snow for stairs, slabs and nodeboxes.
Due to the very nature of nodes in Minetest, the snow cannot
handle all situations. Moresnow is made for roofs (which do look
better with a snow cover in winter), slabs, fences etc.

The texture for the winter leaves (the snowy ones) is taken from Moontest,
which can be found at https://github.com/Amaz1/moontest/tree/master/mods/moontest

More documentation can be found in the [Minetest forum](https://forum.minetest.net/posting.php?f=9&t=9811&p=149257) and/or
in the [Wiki](https://github.com/Sokomine/moresnow/wiki).

Version: 1.0
Author: Sokomine
Liscence: GPLv3.0
