return {
    delay = 5, -- in seconds
    announcements = {
        "Edit announcements over at mods/announce/config.lua",
        "You can use &cC&eO&aL&bO&9R&dS &f(reference at: http://ess.khhq.net/mc/)"
    }
}
