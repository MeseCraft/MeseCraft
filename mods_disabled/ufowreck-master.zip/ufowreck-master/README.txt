Ufo wreck mod by Irremann

Based on "scifi_nodes" and "amcaw" mods. Warning: there may be conflicts, do not use them together.

This mod creates a fleet of 4-6 UFOs when generating a map. Although UFOs are damaged during landing, you can find alien artifacts and plants inside them. ( Our researchers are not sure about plants, perhaps they are animals).

But be careful! Somewhere in the hull is hidden a cloning unit that creates armed crew members. They call themselves "floob" and attack all living things around them without hesitation.

Our researchers also report that electrical devices from UFOs operate at high voltage. This can be useful!